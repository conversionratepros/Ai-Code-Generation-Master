(function () {
    try {
        /* main variables */
        var debug = 0;
        var variation_name = "";
        /* all Pure helper functions */
        function waitForElement(selector, trigger) {
            var interval = setInterval(function () {
                if (document && document.querySelector(selector) && document.querySelectorAll(selector).length > 0) {
                    clearInterval(interval);
                    trigger();
                }
            }, 50);
            setTimeout(function () {
                clearInterval(interval);
            }, 15000);
        }
        function live(selector, event, callback, context) {
            // helper for enabling IE 8 event bindings
            function addEvent(el, type, handler) {
                if (el.attachEvent) el.attachEvent("on" + type, handler);
                else el.addEventListener(type, handler);
            }
            // matches polyfill
            this &&
                this.Element &&
                (function (ElementPrototype) {
                    ElementPrototype.matches =
                        ElementPrototype.matches ||
                        ElementPrototype.matchesSelector ||
                        ElementPrototype.webkitMatchesSelector ||
                        ElementPrototype.msMatchesSelector ||
                        function (selector) {
                            var node = this,
                                nodes = (node.parentNode || node.document).querySelectorAll(selector),
                                i = -1;
                            while (nodes[++i] && nodes[i] != node);
                            return !!nodes[i];
                        };
                })(Element.prototype);
            // live binding helper using matchesSelector
            function live(selector, event, callback, context) {
                addEvent(context || document, event, function (e) {
                    var found,
                        el = e.target || e.srcElement;
                    while (el && el.matches && el !== context && !(found = el.matches(selector))) el = el.parentElement;
                    if (found) callback.call(el, e);
                });
            }
            live(selector, event, callback, context);
        }
        function insertHtml(selector, content, position) {
            var el = document.querySelector(selector);
            if (!position) {
                position = "afterend";
            }
            if (el && content) {
                el.insertAdjacentHTML(position, content);
            }
        }
        function addClass(el, cls) {
            var el = document.querySelector(el);
            if (el) {
                el.classList.add(cls);
            }
        }
        function removeClass(el, cls) {
            var el = document.querySelector(el);
            if (el) {
                el.classList.contains(cls) && el.classList.remove(cls);
            }
        }
        var popup = `
          <div class="cre-t-25-lightBox"><div class="cre-t-25-overlay"></div>
          <div class="cre-t-25-modal">
          <div class="cre-t-25-cards">
  
      </div>
    <div class="cre-t-25-cross">x</div></div></div>
          `;
        var creStyle = `
        section.new-sec {
    display: none;
}

app-footer {
    display: none;
}

.registerholder .container>  .d-flex > div:not(.mobilespce) {
    display: none;
}

header {
    display: none;
}
      `;

        function fetch() {
            var iframe = document.createElement("iframe");
            // Set iframe attributes
            iframe.src = "https://justmoneycreditsav.co.za/register?croTestForm";
            // iframe.src = "https://mobbin.com/pricing?CRE_T25";
            iframe.width = "780";
            iframe.height = "400";
            iframe.frameborder = "0";
            iframe.classList.add("cre-t-25-iframe");

            // Append iframe to a container element

            // document.querySelector('body').appendChild(iframe);
            // body
            // document.querySelector("#__next").preChild(iframe);

            if (!document.querySelector('cro25')) {
                document.querySelector('body').insertAdjacentHTML('afterend', '<cro25></cro25>')
                document.querySelector('cro25').insertAdjacentElement('afterbegin', iframe)
            }

            iframe.onload = function () {
                // Access the content of the iframe
                var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

                // Find the element within the iframe using the selector
                var pricingCardsElement = iframeDocument.querySelector('.mobilespce');
                var pricingBody = iframeDocument.querySelector("body");
                var priceHead = iframeDocument.querySelector("head");
                if (priceHead) {
                    priceHead.insertAdjacentHTML("beforeend", creStyle);
                }
                // Do something with the found element, such as changing its style
                if (pricingCardsElement) {
                    // pricingCardsElement.style.border = '2px solid red'; // Example: Adding a border for demonstration
                }

                if (pricingBody) {
                    pricingBody.classList.add("cro-t-25-form");
                    //   addClass("body", "cro-t-25-form");
                    // waitForElement(
                    //     '[data-testid="pricing-cards"]',
                    //     function () {
                    //         var pricingCard = document.querySelector('[data-testid="pricing-cards"]');
                    //         var cardParent = pricingCard.closest(".col-start-2");
                    //         cardParent && cardParent.classList.add("cre-pricing-parents");
                    //     }
                    // );
                }
            };
        }
        /* Variation Init */
        function init() {
            addClass("body", "cro-t-25");
            // addClass('body', 'cre-t-25-hide')
            // if (!document.querySelector(".cre-t-25-modal")) {
            //     // insertHtml('body[data-path="/browse/ios/apps"]', popup, "afterbegin");
            //     fetch();
            // }

            fetch()
        }

        // live(".cre-t-25-cross, .cre-t-25-overlay", "click", function () {
        //     addClass("body", "cre-t-25-hide");
        // });
        /* Initialise variation */
        waitForElement("body", function () {
            init()
        });

    } catch (e) {
        if (debug) console.log(e, "error in Test" + variation_name);
    }
})();